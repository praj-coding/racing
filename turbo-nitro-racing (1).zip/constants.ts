
export const CANVAS_WIDTH = 1200;
export const CANVAS_HEIGHT = 800;

export const HIGHWAY_WIDTH = 600;
export const LANES = 4;
export const LANE_WIDTH = HIGHWAY_WIDTH / LANES;

export const PHYSICS = {
  ACCELERATION: 0.25,
  BRAKE: 0.6,
  FRICTION: 0.99,
  MAX_SPEED: 35, // Increased base max speed for gear depth
  BOOST_MAX_SPEED: 55,
  BOOST_ACCELERATION: 0.8,
  BOOST_CHARGE_RATE: 0.35,
  BOOST_CONSUME_RATE: 1.0,
  TRAFFIC_SPEED_MIN: 5,
  TRAFFIC_SPEED_MAX: 15,
  LANE_CHANGE_SPEED: 0.15,
  GRAVITY: 0.5,
  JUMP_FORCE: 12,
  CENTRIFUGAL_FORCE: 0.05
};

export const GEAR_SPEED_CAPS = [
  8,   // Gear 1
  16,  // Gear 2
  26,  // Gear 3
  38,  // Gear 4
  48,  // Gear 5
  60   // Gear 6 (High Speed)
];

export const COLORS = {
  ASPHALT: '#1e293b',
  MARKING: '#facc15',
  CITY_SIDE: '#0f172a',
  DESERT_SIDE: '#78350f',
  P1: '#3b82f6',
  P2: '#f97316',
  TRAFFIC: ['#94a3b8', '#ef4444', '#10b981', '#ffffff'],
  BOOST: '#06b6d4',
  RAMP: '#fbbf24',
  TURBO: '#22c55e',
  OIL: '#000000',
  HEALTH: '#ef4444'
};
