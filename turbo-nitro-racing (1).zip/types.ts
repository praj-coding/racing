
export enum GameMode {
  MENU = 'MENU',
  RACING = 'RACING',
  RESULTS = 'RESULTS'
}

export type DeviceMode = 'COMPUTER' | 'MOBILE';
export type GearboxMode = 'AUTO' | 'MANUAL';
export type SpoilerType = 'none' | 'low' | 'high';
export type WheelType = 'stock' | 'rims' | 'neon';
export type CarModel = 'sedan' | 'supercar' | 'hypercar' | 'muscle' | 'truck';

export interface PlayerConfig {
  name: string;
  color: string;
  model: CarModel;
  spoiler: SpoilerType;
  wheels: WheelType;
}

export interface RaceResult {
  playerName: string;
  distance: number;
  topSpeed: number;
  rank: number;
}

export interface TrafficCar {
  id: number;
  x: number;
  y: number;
  speed: number;
  lane: number;
  color: string;
  type: CarModel;
}

export type FeatureType = 'RAMP' | 'TURBO' | 'OIL' | 'HEALTH';

export interface RoadFeature {
  id: number;
  x: number;
  y: number;
  type: FeatureType;
}

export interface CarState extends PlayerConfig {
  x: number;
  y: number;
  z: number;
  vz: number;
  targetX: number;
  speed: number;
  distance: number;
  finished: boolean;
  lane: number;
  health: number;
  boost: number;
  isBoosting: boolean;
  isAirborne: boolean;
  gear: number;
  rpm: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}
