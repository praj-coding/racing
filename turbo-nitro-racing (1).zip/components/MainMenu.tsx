
import React, { useState } from 'react';
import { PlayerConfig, DeviceMode, GearboxMode, SpoilerType, WheelType, CarModel } from '../types.ts';
import { audioManager } from '../services/audio.ts';

interface MainMenuProps {
  onStart: (players: PlayerConfig[], theme: 'CITY' | 'DESERT', deviceMode: DeviceMode, gearbox: GearboxMode) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onStart }) => {
  const [numPlayers, setNumPlayers] = useState<1 | 2>(1);
  const [p1, setP1] = useState<PlayerConfig>({ name: 'Racer One', color: '#3b82f6', model: 'supercar', spoiler: 'low', wheels: 'rims' });
  const [p2, setP2] = useState<PlayerConfig>({ name: 'Racer Two', color: '#f97316', model: 'muscle', spoiler: 'high', wheels: 'stock' });
  
  const [theme, setTheme] = useState<'CITY' | 'DESERT'>('CITY');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('COMPUTER');
  const [gearbox, setGearbox] = useState<GearboxMode>('AUTO');

  const handleStart = () => {
    audioManager.playStartEngine();
    const players: PlayerConfig[] = [p1];
    if (numPlayers === 2) players.push(p2);
    setTimeout(() => onStart(players, theme, deviceMode, gearbox), 500);
  };

  const renderGarage = (player: PlayerConfig, setPlayer: React.Dispatch<React.SetStateAction<PlayerConfig>>, label: string) => (
    <div className="space-y-4 p-4 bg-black/40 rounded-2xl border border-white/5">
      <label className="block text-xs font-bold uppercase text-slate-500 mb-2">{label}</label>
      <input 
        value={player.name}
        onChange={e => setPlayer({ ...player, name: e.target.value })}
        className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 focus:ring-2 focus:ring-blue-500 font-orbitron text-sm text-white"
      />
      
      <div className="grid grid-cols-2 gap-2">
        <div>
          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Body Model</span>
          <select 
            value={player.model}
            onChange={e => setPlayer({ ...player, model: e.target.value as CarModel })}
            className="w-full bg-slate-800 border-none rounded-lg text-xs py-1.5 px-2 focus:outline-none text-white capitalize"
          >
            <option value="sedan">Sedan</option>
            <option value="supercar">Supercar</option>
            <option value="hypercar">Hypercar</option>
            <option value="muscle">Muscle</option>
            <option value="truck">Truck</option>
          </select>
        </div>
        
        <div>
          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Body Color</span>
          <div className="flex items-center gap-2">
            <input type="color" value={player.color} onChange={e => setPlayer({ ...player, color: e.target.value })} className="w-8 h-8 rounded bg-transparent cursor-pointer" />
            <span className="text-[10px] text-white/50 font-mono">{player.color}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div>
          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Spoiler</span>
          <select 
            value={player.spoiler}
            onChange={e => setPlayer({ ...player, spoiler: e.target.value as SpoilerType })}
            className="w-full bg-slate-800 border-none rounded-lg text-xs py-1.5 px-2 focus:outline-none"
          >
            <option value="none">None</option>
            <option value="low">Sport Lip</option>
            <option value="high">GT Wing</option>
          </select>
        </div>
        <div>
          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Wheels</span>
          <select 
            value={player.wheels}
            onChange={e => setPlayer({ ...player, wheels: e.target.value as WheelType })}
            className="w-full bg-slate-800 border-none rounded-lg text-xs py-1.5 px-2 focus:outline-none"
          >
            <option value="stock">Stock</option>
            <option value="rims">Rims</option>
            <option value="neon">Neon</option>
          </select>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-white overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-tr from-blue-900/20 to-purple-900/20 pointer-events-none" />
      
      <div className="z-10 text-center mb-8">
        <h1 className="text-6xl md:text-8xl font-black font-orbitron tracking-tighter mb-2 italic">
          TURBO <span className="text-blue-500">NITRO</span>
        </h1>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-12 bg-blue-500/50" />
          <p className="text-slate-400 font-bold tracking-[0.3em] uppercase italic text-xs">Custom Garage</p>
          <div className="h-px w-12 bg-blue-500/50" />
        </div>
      </div>

      <div className="z-10 bg-slate-900/80 backdrop-blur-xl p-8 rounded-3xl border border-white/10 shadow-2xl w-full max-w-3xl">
        <div className="space-y-6">
          <div className="flex gap-4">
            <button onClick={() => setNumPlayers(1)} className={`flex-1 p-3 rounded-xl border transition-all ${numPlayers === 1 ? 'border-blue-500 bg-blue-500/10' : 'border-white/5'}`}>
              <span className="block font-bold">SOLO</span>
            </button>
            <button onClick={() => setNumPlayers(2)} className={`flex-1 p-3 rounded-xl border transition-all ${numPlayers === 2 ? 'border-orange-500 bg-orange-500/10' : 'border-white/5'}`}>
              <span className="block font-bold">DUEL</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {renderGarage(p1, setP1, 'Driver 1 Garage')}
            {numPlayers === 2 && renderGarage(p2, setP2, 'Driver 2 Garage')}
          </div>

          <div className="grid grid-cols-3 gap-4">
             <div className="flex flex-col gap-1 bg-black/40 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] font-bold uppercase text-slate-500 text-center">Gearbox</span>
              <div className="flex bg-slate-800 p-1 rounded-lg">
                <button onClick={() => setGearbox('AUTO')} className={`flex-1 py-1 rounded-md text-[10px] ${gearbox === 'AUTO' ? 'bg-blue-600' : 'text-slate-400'}`}>Auto</button>
                <button onClick={() => setGearbox('MANUAL')} className={`flex-1 py-1 rounded-md text-[10px] ${gearbox === 'MANUAL' ? 'bg-blue-600' : 'text-slate-400'}`}>Manual</button>
              </div>
            </div>
            <div className="flex flex-col gap-1 bg-black/40 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] font-bold uppercase text-slate-500 text-center">Input</span>
              <div className="flex bg-slate-800 p-1 rounded-lg">
                <button onClick={() => setDeviceMode('COMPUTER')} className={`flex-1 py-1 rounded-md text-[10px] ${deviceMode === 'COMPUTER' ? 'bg-slate-600' : 'text-slate-400'}`}>PC</button>
                <button onClick={() => setDeviceMode('MOBILE')} className={`flex-1 py-1 rounded-md text-[10px] ${deviceMode === 'MOBILE' ? 'bg-blue-600' : 'text-slate-400'}`}>Touch</button>
              </div>
            </div>
            <div className="flex flex-col gap-1 bg-black/40 p-2 rounded-xl border border-white/5">
              <span className="text-[9px] font-bold uppercase text-slate-500 text-center">Map</span>
              <div className="flex bg-slate-800 p-1 rounded-lg">
                <button onClick={() => setTheme('CITY')} className={`flex-1 py-1 rounded-md text-[10px] ${theme === 'CITY' ? 'bg-slate-600' : 'text-slate-400'}`}>Neon</button>
                <button onClick={() => setTheme('DESERT')} className={`flex-1 py-1 rounded-md text-[10px] ${theme === 'DESERT' ? 'bg-amber-700' : 'text-slate-400'}`}>Sand</button>
              </div>
            </div>
          </div>

          <button 
            onClick={handleStart}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 py-5 rounded-2xl font-orbitron font-black text-2xl tracking-tight shadow-[0_0_40px_rgba(37,99,235,0.4)] transition-all active:scale-95"
          >
            IGNITE ENGINES
          </button>
        </div>
      </div>
    </div>
  );
};
