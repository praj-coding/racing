
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  HIGHWAY_WIDTH, 
  LANE_WIDTH, 
  LANES, 
  PHYSICS, 
  GEAR_SPEED_CAPS,
  COLORS 
} from '../constants.ts';
import { CarState, TrafficCar, Particle, PlayerConfig, RaceResult, DeviceMode, RoadFeature, FeatureType, GearboxMode, SpoilerType, WheelType, CarModel } from '../types.ts';
import { audioManager } from '../services/audio.ts';

interface GameCanvasProps {
  players: PlayerConfig[];
  onFinish: (results: RaceResult[]) => void;
  onLeave: () => void;
  theme: 'CITY' | 'DESERT';
  deviceMode: DeviceMode;
  gearboxMode: GearboxMode;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ players, onFinish, onLeave, theme, deviceMode, gearboxMode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [playerCars, setPlayerCars] = useState<CarState[]>([]);
  const [traffic, setTraffic] = useState<TrafficCar[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  
  const particles = useRef<Particle[]>([]);
  const keys = useRef<Set<string>>(new Set());
  const requestRef = useRef<number>(0);
  const trafficCounter = useRef<number>(0);
  const frameCount = useRef<number>(0);
  const collidedTrafficIds = useRef<Set<number>>(new Set());
  const prevBoosting = useRef<boolean[]>(players.map(() => false));
  const screenShake = useRef<number>(0);

  const getRoadX = (dist: number) => {
    return Math.sin(dist * 0.0005) * 300 + Math.sin(dist * 0.0012) * 150 + Math.cos(dist * 0.0003) * 100;
  };

  useEffect(() => {
    audioManager.startMusic();
    return () => audioManager.stopMusic();
  }, []);

  useEffect(() => {
    const initialPlayers: CarState[] = players.map((p, i) => {
      const lane = i + 1;
      const initialDist = 0;
      const roadX = getRoadX(initialDist);
      const hLeft = (CANVAS_WIDTH - HIGHWAY_WIDTH) / 2 + roadX;
      const x = hLeft + (lane * LANE_WIDTH) - (LANE_WIDTH / 2);
      return {
        ...p, x, y: CANVAS_HEIGHT - 150, z: 0, vz: 0, targetX: x, speed: 0, distance: initialDist,
        finished: false, lane, health: 100, boost: 0, isBoosting: false, isAirborne: false, gear: 1, rpm: 0
      };
    });
    setPlayerCars(initialPlayers);
  }, [players]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.code === 'Escape') setIsPaused(prev => !prev);
    keys.current.add(e.code);
  }, []);

  const handleKeyUp = useCallback((e: KeyboardEvent) => keys.current.delete(e.code), []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => { window.removeEventListener('keydown', handleKeyDown); window.removeEventListener('keyup', handleKeyUp); };
  }, [handleKeyDown, handleKeyUp]);

  const handleTouchStart = (key: string) => { keys.current.add(key); if (navigator.vibrate) navigator.vibrate(20); };
  const handleTouchEnd = (key: string) => keys.current.delete(key);

  const spawnTraffic = useCallback((dist: number) => {
    const lane = Math.floor(Math.random() * LANES);
    const roadX = getRoadX(dist + CANVAS_HEIGHT + 200);
    const x = (CANVAS_WIDTH - HIGHWAY_WIDTH) / 2 + roadX + (lane * LANE_WIDTH) + (LANE_WIDTH / 2);
    const types: CarModel[] = ['sedan', 'supercar', 'hypercar', 'muscle', 'truck'];
    const type = types[Math.floor(Math.random() * types.length)];
    const speed = PHYSICS.TRAFFIC_SPEED_MIN + Math.random() * (PHYSICS.TRAFFIC_SPEED_MAX - PHYSICS.TRAFFIC_SPEED_MIN);
    const newTraffic: TrafficCar = { 
      id: trafficCounter.current++, 
      x, 
      y: -200, 
      speed, 
      lane, 
      color: COLORS.TRAFFIC[Math.floor(Math.random() * COLORS.TRAFFIC.length)], 
      type 
    };
    setTraffic(prev => [...prev.filter(t => t.y < CANVAS_HEIGHT + 400), newTraffic]);
  }, []);

  const createExplosion = (x: number, y: number) => {
    for (let i = 0; i < 40; i++) {
      particles.current.push({
        x, y,
        vx: (Math.random() - 0.5) * 25,
        vy: (Math.random() - 0.5) * 25,
        life: 1.0 + Math.random() * 0.5,
        color: Math.random() > 0.3 ? '#f97316' : '#ef4444',
        size: 8 + Math.random() * 12
      });
    }
  };

  const update = useCallback(() => {
    if (isPaused) { requestRef.current = requestAnimationFrame(update); return; }
    frameCount.current++;
    collidedTrafficIds.current.clear();
    const leadDistance = Math.max(...playerCars.map(p => p.distance), 0);
    if (frameCount.current % 50 === 0) spawnTraffic(leadDistance);
    if (screenShake.current > 0) screenShake.current *= 0.85;

    setPlayerCars(prevPlayers => {
      const updated = prevPlayers.map((player, idx) => {
        let nextPlayer = { ...player };

        if (nextPlayer.health <= 0) {
          nextPlayer.speed *= 0.97;
          nextPlayer.rpm = 0;
          nextPlayer.isBoosting = false;
          nextPlayer.distance += nextPlayer.speed;
          if (frameCount.current % 2 === 0 && nextPlayer.speed > 0.5) {
            particles.current.push({
              x: nextPlayer.x + (Math.random() - 0.5) * 15,
              y: nextPlayer.y + 20,
              vx: (Math.random() - 0.5) * 2,
              vy: 5 + Math.random() * 8,
              life: 1.5,
              color: 'rgba(80, 80, 80, 0.5)',
              size: 6 + Math.random() * 10
            });
          }
          return nextPlayer;
        }

        const controls = idx === 0 
          ? { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', boost: 'ShiftRight', gearUp: 'KeyE', gearDown: 'KeyQ' }
          : { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD', boost: 'ShiftLeft', gearUp: 'KeyR', gearDown: 'KeyF' };

        if (gearboxMode === 'MANUAL') {
           if (keys.current.has(controls.gearUp)) {
             if (nextPlayer.gear < 6) { nextPlayer.gear++; keys.current.delete(controls.gearUp); audioManager.playEngine(nextPlayer.speed); }
           }
           if (keys.current.has(controls.gearDown)) {
             if (nextPlayer.gear > 1) { nextPlayer.gear--; keys.current.delete(controls.gearDown); audioManager.playEngine(nextPlayer.speed * 1.5); }
           }
        }

        const currentRoadX = getRoadX(nextPlayer.distance);
        const lookAheadRoadX = getRoadX(nextPlayer.distance + 10);
        nextPlayer.x += (lookAheadRoadX - currentRoadX) * (nextPlayer.speed * 0.05);

        const isPressingBoost = keys.current.has(controls.boost);
        if (isPressingBoost && nextPlayer.boost > 0) {
          nextPlayer.isBoosting = true;
          if (!prevBoosting.current[idx]) screenShake.current = 10;
        } else {
          nextPlayer.isBoosting = false;
        }
        prevBoosting.current[idx] = nextPlayer.isBoosting;

        let accelMod = 1.0;
        let speedMod = 1.0;
        if (nextPlayer.model === 'muscle') { accelMod = 1.4; speedMod = 0.9; }
        if (nextPlayer.model === 'hypercar') { accelMod = 0.8; speedMod = 1.25; }
        if (nextPlayer.model === 'truck') { accelMod = 0.6; speedMod = 0.7; }

        const currentGearCap = GEAR_SPEED_CAPS[nextPlayer.gear - 1] * speedMod;
        const prevGearCap = nextPlayer.gear > 1 ? GEAR_SPEED_CAPS[nextPlayer.gear - 2] * speedMod : 0;
        
        if (nextPlayer.isBoosting) {
          nextPlayer.speed += PHYSICS.BOOST_ACCELERATION * accelMod;
          nextPlayer.boost -= PHYSICS.BOOST_CONSUME_RATE;
        } else if (keys.current.has(controls.up)) {
          if (nextPlayer.speed < currentGearCap) nextPlayer.speed += PHYSICS.ACCELERATION * accelMod;
          else {
            nextPlayer.speed = currentGearCap;
            if (gearboxMode === 'AUTO' && nextPlayer.gear < 6) nextPlayer.gear++;
          }
          nextPlayer.boost = Math.min(100, nextPlayer.boost + PHYSICS.BOOST_CHARGE_RATE);
        } else if (keys.current.has(controls.down)) {
          nextPlayer.speed -= PHYSICS.BRAKE;
        } else {
          nextPlayer.speed *= PHYSICS.FRICTION;
        }

        const absoluteMax = (nextPlayer.isBoosting ? PHYSICS.BOOST_MAX_SPEED : currentGearCap) * speedMod;
        if (nextPlayer.speed > absoluteMax && !nextPlayer.isBoosting) nextPlayer.speed = absoluteMax;
        if (nextPlayer.speed < 0) nextPlayer.speed = 0;

        nextPlayer.rpm = Math.max(0, Math.min(100, ((nextPlayer.speed - prevGearCap) / (currentGearCap - prevGearCap)) * 100));
        if (keys.current.has(controls.left)) nextPlayer.x -= 12;
        if (keys.current.has(controls.right)) nextPlayer.x += 12;
        nextPlayer.distance += nextPlayer.speed;

        traffic.forEach(t => {
          const dx = Math.abs(nextPlayer.x - t.x);
          const dy = Math.abs(nextPlayer.y - t.y);
          const hitboxW = t.type === 'truck' ? 55 : 35;
          const hitboxH = t.type === 'truck' ? 120 : 75;
          if (dx < hitboxW && dy < hitboxH) {
            const relativeSpeed = Math.abs(nextPlayer.speed - t.speed);
            const damage = (10 + (relativeSpeed * 2.5)) * (nextPlayer.model === 'truck' ? 0.5 : (nextPlayer.model === 'hypercar' ? 1.5 : 1.0));
            nextPlayer.health -= damage;
            nextPlayer.speed *= 0.4;
            screenShake.current = 10 + (relativeSpeed * 1.5);
            audioManager.playCollision();
            collidedTrafficIds.current.add(t.id);
            if (nextPlayer.health <= 0) {
              nextPlayer.health = 0;
              createExplosion(nextPlayer.x, nextPlayer.y);
              if (navigator.vibrate) navigator.vibrate([150, 50, 300]);
            }
          }
        });
        return nextPlayer;
      });

      const maxSpeed = Math.max(...updated.map(p => p.speed), 0);
      setTraffic(prev => prev.filter(t => !collidedTrafficIds.current.has(t.id)).map(t => ({ ...t, y: t.y + (t.speed - (maxSpeed * 0.55)) })));
      particles.current = particles.current.map(p => ({ ...p, x: p.x + p.vx, y: p.y + p.vy, life: p.life - 0.02 })).filter(p => p.life > 0);

      if (updated.every(p => p.health <= 0 || p.distance > 1000000) && !gameOver) {
        setGameOver(true);
        setTimeout(() => onFinish(updated.map(p => ({ playerName: p.name, distance: Math.floor(p.distance/100), topSpeed: Math.floor(PHYSICS.MAX_SPEED * 8), rank: 1 }))), 3500);
      }
      return updated;
    });
    requestRef.current = requestAnimationFrame(update);
  }, [playerCars, spawnTraffic, onFinish, gameOver, isPaused, traffic, gearboxMode]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => cancelAnimationFrame(requestRef.current!);
  }, [update]);

  const drawHeadlightBeams = (ctx: CanvasRenderingContext2D, car: CarState | TrafficCar, width: number, height: number) => {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    
    const beamLength = 350;
    const beamWidth = 120;
    const headlightSpacing = width * 0.35;
    
    const drawSingleBeam = (xOffset: number) => {
      const grad = ctx.createLinearGradient(xOffset, -height/2, xOffset, -height/2 - beamLength);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
      grad.addColorStop(0.3, 'rgba(255, 255, 255, 0.1)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(xOffset - 5, -height/2);
      ctx.lineTo(xOffset + 5, -height/2);
      ctx.lineTo(xOffset + beamWidth/2, -height/2 - beamLength);
      ctx.lineTo(xOffset - beamWidth/2, -height/2 - beamLength);
      ctx.closePath();
      ctx.fill();
    };

    drawSingleBeam(-headlightSpacing);
    drawSingleBeam(headlightSpacing);
    ctx.restore();
  };

  const drawDetailedCar = (ctx: CanvasRenderingContext2D, car: CarState | TrafficCar, isPlayer: boolean) => {
    const isDestroyed = isPlayer && (car as CarState).health <= 0;
    const model = isPlayer ? (car as CarState).model : (car as TrafficCar).type;
    const baseColor = isDestroyed ? '#1a1a1a' : car.color;
    const isBraking = isPlayer && keys.current.has((car as CarState).name === players[0].name ? 'ArrowDown' : 'KeyS');
    
    let width = 40; 
    let height = 80;
    if (model === 'truck') { width = 55; height = 110; }
    if (model === 'hypercar') { width = 44; height = 90; }
    if (model === 'muscle') { width = 46; height = 82; }

    ctx.save();

    // Lighting: Headlight Beams
    if (!isDestroyed) {
      drawHeadlightBeams(ctx, car, width, height);
    }

    // Shadow
    ctx.shadowBlur = 15;
    ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.roundRect(-width/2, -height/2, width, height, model === 'muscle' ? 4 : 10); 
    ctx.fill();
    ctx.shadowBlur = 0;

    // Body Base
    const gradient = ctx.createLinearGradient(-width/2, 0, width/2, 0);
    gradient.addColorStop(0, baseColor);
    gradient.addColorStop(0.5, isDestroyed ? '#333' : '#fff');
    gradient.addColorStop(1, baseColor);
    ctx.fillStyle = isDestroyed ? '#111' : gradient;

    ctx.beginPath();
    if (model === 'hypercar') {
      ctx.moveTo(0, -height/2);
      ctx.lineTo(width/2, -height/2 + 15);
      ctx.lineTo(width/2, height/2 - 10);
      ctx.lineTo(width/2 - 5, height/2);
      ctx.lineTo(-width/2 + 5, height/2);
      ctx.lineTo(-width/2, height/2 - 10);
      ctx.lineTo(-width/2, -height/2 + 15);
      ctx.closePath();
    } else if (model === 'muscle') {
      ctx.roundRect(-width/2, -height/2, width, height, 4);
    } else if (model === 'truck') {
      ctx.roundRect(-width/2, -height/2, width, height, 8);
    } else {
      ctx.roundRect(-width/2, -height/2, width, height, 12);
    }
    ctx.fill();

    // Reflections/Gloss
    if (!isDestroyed) {
      ctx.save();
      ctx.globalAlpha = 0.3;
      const glossGrad = ctx.createLinearGradient(-width/2, -height/2, width/2, height/2);
      glossGrad.addColorStop(0, 'rgba(255,255,255,0.8)');
      glossGrad.addColorStop(0.5, 'rgba(255,255,255,0)');
      glossGrad.addColorStop(1, 'rgba(255,255,255,0.3)');
      ctx.fillStyle = glossGrad;
      ctx.fill();
      ctx.restore();
    }

    if (!isDestroyed) {
      if (model === 'muscle') {
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.fillRect(-8, -height * 0.25, 16, 12);
      }
      if (model === 'truck') {
        ctx.fillStyle = 'rgba(0,0,0,0.2)';
        ctx.fillRect(-width * 0.4, height * 0.1, width * 0.8, height * 0.35);
      }
      if (model === 'hypercar') {
        ctx.fillStyle = '#111';
        ctx.fillRect(-width * 0.5, -height * 0.45, width, 5);
      }
    }

    if (isPlayer) {
      const p = car as CarState;
      ctx.fillStyle = isDestroyed ? '#000' : '#222';
      if (p.spoiler === 'low') ctx.fillRect(-width * 0.45, height * 0.38, width * 0.9, 5);
      else if (p.spoiler === 'high') {
        ctx.fillRect(-width * 0.5, height * 0.42, width, 8);
        ctx.fillRect(-width * 0.35, height * 0.35, 3, 10);
        ctx.fillRect(width * 0.35 - 3, height * 0.35, 3, 10);
      }
    }

    // Wheels
    const wheels = isPlayer ? (car as CarState).wheels : 'stock';
    const wheelC = isDestroyed ? '#000' : (wheels === 'rims' ? '#cbd5e1' : '#000');
    const wH = model === 'truck' ? 24 : 16; 
    const wW = model === 'truck' ? 12 : 8;
    const drawWheel = (x: number, y: number) => {
      ctx.fillStyle = wheelC;
      ctx.fillRect(x, y, wW, wH);
      if (wheels === 'neon' && !isDestroyed) {
        ctx.save(); ctx.strokeStyle = car.color; ctx.lineWidth = 2; ctx.shadowBlur = 12; ctx.shadowColor = car.color;
        ctx.strokeRect(x - 1, y - 1, wW + 2, wH + 2); ctx.restore();
      }
    };
    drawWheel(-width/2 - wW, -height/2 + 12); drawWheel(width/2, -height/2 + 12);
    drawWheel(-width/2 - wW, height/2 - 28); drawWheel(width/2, height/2 - 28);

    // Glass
    ctx.fillStyle = isDestroyed ? '#000' : 'rgba(2, 6, 23, 0.9)';
    ctx.beginPath(); 
    const glassW = width * 0.76;
    const glassH = height * (model === 'truck' ? 0.2 : 0.35);
    ctx.roundRect(-glassW/2, -height * 0.22, glassW, glassH, 4); 
    ctx.fill();

    // Headlights (Visual emitters)
    if (!isDestroyed) {
      ctx.save(); 
      ctx.fillStyle = '#fff'; 
      ctx.shadowBlur = 20; 
      ctx.shadowColor = '#fff';
      const headlightW = model === 'truck' ? 14 : 10;
      ctx.fillRect(-width * 0.42, -height * 0.48, headlightW, 5); 
      ctx.fillRect(width * 0.42 - headlightW, -height * 0.48, headlightW, 5); 
      ctx.restore();
    }

    // Brake Lights
    if (!isDestroyed) {
      ctx.save();
      const brakeColor = isBraking ? '#ff0000' : '#880000';
      ctx.fillStyle = brakeColor;
      if (isBraking) {
        ctx.shadowBlur = 25;
        ctx.shadowColor = '#ff0000';
      }
      ctx.fillRect(-width * 0.4, height * 0.42, 10, 4);
      ctx.fillRect(width * 0.4 - 10, height * 0.42, 10, 4);
      ctx.restore();
    }
    
    ctx.restore();
  };

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const render = () => {
      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.save();
      if (screenShake.current > 0) ctx.translate((Math.random() - 0.5) * screenShake.current, (Math.random() - 0.5) * screenShake.current);
      
      const camDist = Math.max(...playerCars.map(p => p.distance), 0);
      const roadLeft = (CANVAS_WIDTH - HIGHWAY_WIDTH)/2;
      
      // Terrain
      ctx.fillStyle = theme === 'CITY' ? '#070b14' : '#5d2b0c'; 
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Asphalt base
      ctx.fillStyle = COLORS.ASPHALT;
      ctx.fillRect(roadLeft, 0, HIGHWAY_WIDTH, CANVAS_HEIGHT);

      // Dynamic Road Reflections (Subtle pool effects)
      ctx.globalAlpha = 0.1;
      playerCars.concat(traffic as any).forEach(car => {
        const roadGrad = ctx.createRadialGradient(car.x, car.y, 0, car.x, car.y, 150);
        roadGrad.addColorStop(0, car.color || '#ffffff');
        roadGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = roadGrad;
        ctx.fillRect(car.x - 150, car.y - 150, 300, 300);
      });
      ctx.globalAlpha = 1.0;

      // Road Markings
      ctx.strokeStyle = 'rgba(255,255,255,0.15)';
      ctx.setLineDash([30, 60]);
      ctx.lineDashOffset = -camDist % 90;
      for(let i = 1; i < LANES; i++) {
        ctx.beginPath(); ctx.moveTo(roadLeft + i * LANE_WIDTH, 0); ctx.lineTo(roadLeft + i * LANE_WIDTH, CANVAS_HEIGHT); ctx.stroke();
      }
      ctx.setLineDash([]);

      // Draw Entities
      traffic.forEach(t => { ctx.save(); ctx.translate(t.x, t.y); drawDetailedCar(ctx, t, false); ctx.restore(); });
      playerCars.forEach(p => { ctx.save(); ctx.translate(p.x, p.y); drawDetailedCar(ctx, p, true); ctx.restore(); });
      
      // Global Lighting Overlay (Vignette & Darkness)
      const overlayGrad = ctx.createRadialGradient(CANVAS_WIDTH/2, CANVAS_HEIGHT/2, 100, CANVAS_WIDTH/2, CANVAS_HEIGHT/2, 800);
      overlayGrad.addColorStop(0, 'rgba(0,0,0,0)');
      overlayGrad.addColorStop(1, 'rgba(0,0,0,0.6)');
      ctx.fillStyle = overlayGrad;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      particles.current.forEach(p => {
        ctx.save(); ctx.globalAlpha = Math.min(1, p.life); ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2); ctx.fill(); ctx.restore();
      });

      if (isPaused) {
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      }
      
      ctx.restore();
    };
    render();
  }, [playerCars, traffic, theme, isPaused]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-black overflow-hidden">
      <div className="flex-1 w-full relative flex items-center justify-center">
        <canvas ref={canvasRef} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} className="max-w-full max-h-full object-contain shadow-[0_0_100px_rgba(0,0,0,1)] rounded-lg bg-black"/>
        
        {/* TOP HUD: Pause Button */}
        <div className="absolute top-6 right-6 flex items-center gap-4 z-50">
           <button 
             onClick={() => setIsPaused(prev => !prev)}
             className="w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full border border-white/20 flex items-center justify-center transition-all active:scale-90"
           >
             {isPaused ? (
               <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-white border-b-[8px] border-b-transparent ml-1" />
             ) : (
               <div className="flex gap-1.5">
                 <div className="w-2 h-6 bg-white rounded-full" />
                 <div className="w-2 h-6 bg-white rounded-full" />
               </div>
             )}
           </button>
        </div>

        {/* LEFT HUD: Players Info */}
        <div className="absolute top-6 left-6 flex flex-col gap-6 pointer-events-none">
          {playerCars.map((car, idx) => {
            const isRedline = car.rpm > 90;
            return (
              <div key={idx} className={`bg-black/70 backdrop-blur-xl p-5 rounded-3xl border-l-8 w-80 shadow-2xl transition-all ${car.health <= 0 ? 'border-red-600' : ''}`} style={{ borderLeftColor: car.health <= 0 ? '#dc2626' : car.color }}>
                <div className="flex justify-between items-center mb-1">
                  <span className={`font-orbitron font-black text-xs italic uppercase tracking-widest ${car.health <= 0 ? 'text-red-500' : 'text-white'}`}>
                    {car.name} <span className="text-white/40 ml-2">[{car.model}]</span>
                  </span>
                  <span className="text-[10px] font-mono text-white/40">{Math.floor(car.distance/100)} KM</span>
                </div>
                <div className="flex items-center gap-4 my-2">
                  <div className={`text-5xl font-orbitron font-black italic flex items-baseline gap-2 ${car.health <= 0 ? 'text-slate-700' : 'text-white'}`}>
                    {Math.floor(car.speed * 8.2)} <span className="text-sm text-blue-500 font-bold uppercase tracking-tighter">MPH</span>
                  </div>
                  {car.health > 0 && (
                    <div className={`ml-auto flex flex-col items-center justify-center w-16 h-16 rounded-xl border-2 transition-all ${isRedline && gearboxMode === 'MANUAL' ? 'bg-red-600 border-white animate-pulse shadow-[0_0_20px_#ef4444]' : 'bg-black/50 border-white/20'}`} style={!isRedline ? { borderColor: `${car.color}44` } : {}}>
                      <span className="text-[8px] font-black uppercase text-white/50 leading-none mb-1">Gear</span>
                      <span className="text-3xl font-orbitron font-black leading-none">{car.gear}</span>
                      {isRedline && gearboxMode === 'MANUAL' && <span className="absolute -bottom-1 bg-white text-red-600 text-[8px] font-black px-1 rounded uppercase tracking-tighter">Shift!</span>}
                    </div>
                  )}
                </div>
                <div className="space-y-1 mt-3">
                  <div className="flex justify-between text-[9px] font-black uppercase text-white/50"><span>Integrity</span><span className={car.health < 30 ? 'text-red-500 animate-pulse' : ''}>{Math.floor(car.health)}%</span></div>
                  <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                    <div className={`h-full transition-all duration-300 ${car.health < 30 ? 'bg-red-600 shadow-[0_0_10px_#dc2626]' : 'bg-blue-500'}`} style={{ width: `${car.health}%` }} />
                  </div>
                </div>
                {car.health > 0 ? (
                  <div className="mt-4 flex gap-4">
                    <div className="flex-1"><div className="text-[8px] font-black uppercase text-white/30 mb-1">Engine RPM</div><div className="h-1 bg-white/5 rounded-full overflow-hidden"><div className={`h-full transition-all duration-75 ${car.rpm > 90 ? 'bg-orange-500 shadow-[0_0_8px_#f97316]' : 'bg-white/80'}`} style={{ width: `${car.rpm}%` }} /></div></div>
                    <div className="w-24"><div className="text-[8px] font-black uppercase text-white/30 mb-1">Nitro</div><div className="h-1 bg-white/5 rounded-full overflow-hidden"><div className="h-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] transition-all" style={{ width: `${car.boost}%` }} /></div></div>
                  </div>
                ) : (
                  <div className="mt-4 py-2 bg-red-950/30 rounded-xl border border-red-900/50 text-center"><span className="text-[10px] font-orbitron font-black text-red-500 animate-pulse tracking-widest uppercase">Totaled</span></div>
                )}
              </div>
            );
          })}
        </div>

        {/* PAUSE OVERLAY */}
        {isPaused && (
          <div className="absolute inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-md">
            <div className="bg-slate-900/90 border border-white/10 p-10 rounded-[40px] shadow-[0_0_80px_rgba(0,0,0,0.6)] w-full max-w-md text-center transform scale-110">
              <h2 className="text-4xl font-orbitron font-black italic text-white mb-2 uppercase tracking-tight">Chase Paused</h2>
              <div className="h-1 w-24 bg-blue-600 mx-auto rounded-full mb-8 animate-pulse" />
              
              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => setIsPaused(false)}
                  className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-orbitron font-black text-lg rounded-2xl transition-all shadow-lg active:scale-95"
                >
                  RESUME RACE
                </button>
                <button 
                  onClick={onLeave}
                  className="w-full py-4 bg-white/5 hover:bg-red-600 hover:text-white text-white/60 font-orbitron font-black text-lg rounded-2xl border border-white/10 transition-all active:scale-95"
                >
                  LEAVE TO GARAGE
                </button>
              </div>
              
              <p className="mt-8 text-white/20 text-[10px] font-bold uppercase tracking-widest font-mono">Press ESC to toggle</p>
            </div>
          </div>
        )}
      </div>

      {deviceMode === 'MOBILE' && !gameOver && !isPaused && (
        <div className="absolute inset-0 z-40 pointer-events-none flex items-end justify-between p-10 pb-16 select-none">
          <div className="pointer-events-auto flex flex-col gap-4">
            {gearboxMode === 'MANUAL' && (
              <div className="flex gap-4 mb-4">
                <button onPointerDown={() => handleTouchStart('KeyE')} onPointerUp={() => handleTouchEnd('KeyE')} className="w-20 h-20 bg-blue-600/10 border-2 border-blue-500/30 rounded-2xl flex items-center justify-center text-white font-black italic shadow-xl active:bg-blue-600/40">UP</button>
                <button onPointerDown={() => handleTouchStart('KeyQ')} onPointerUp={() => handleTouchEnd('KeyQ')} className="w-20 h-20 bg-blue-600/10 border-2 border-blue-500/30 rounded-2xl flex items-center justify-center text-white font-black italic shadow-xl active:bg-blue-600/40">DN</button>
              </div>
            )}
            <div className="flex gap-6">
              <button onPointerDown={() => handleTouchStart('ArrowLeft')} onPointerUp={() => handleTouchEnd('ArrowLeft')} className="w-28 h-28 bg-white/5 border-2 border-white/10 rounded-3xl flex items-center justify-center text-6xl active:bg-white/20 transition-all shadow-2xl">◀</button>
              <button onPointerDown={() => handleTouchStart('ArrowRight')} onPointerUp={() => handleTouchEnd('ArrowRight')} className="w-28 h-28 bg-white/5 border-2 border-white/10 rounded-3xl flex items-center justify-center text-6xl active:bg-white/20 transition-all shadow-2xl">▶</button>
            </div>
          </div>
          <div className="pointer-events-auto flex flex-col items-end gap-10">
            <button onPointerDown={() => handleTouchStart('ShiftRight')} onPointerUp={() => handleTouchEnd('ShiftRight')} className="w-32 h-32 bg-cyan-500/10 border-2 border-cyan-400/30 rounded-full flex flex-col items-center justify-center active:bg-cyan-400/50 transition-all shadow-2xl ring-4 ring-cyan-400/10"><span className="text-cyan-400 font-orbitron font-black text-2xl italic tracking-tighter">NITRO</span></button>
            <div className="flex gap-6 items-end">
              <button onPointerDown={() => handleTouchStart('ArrowDown')} onPointerUp={() => handleTouchEnd('ArrowDown')} className="w-24 h-24 bg-red-600/10 border-2 border-red-500/20 rounded-3xl flex flex-col items-center justify-center active:bg-red-500/40 transition-all text-4xl">🛑</button>
              <button onPointerDown={() => handleTouchStart('ArrowUp')} onPointerUp={() => handleTouchEnd('ArrowUp')} className="w-36 h-36 bg-blue-600/10 border-2 border-blue-500/30 rounded-3xl flex flex-col items-center justify-center active:bg-blue-500/50 transition-all shadow-2xl text-6xl">🔥</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
